#include<stdio.h>
#pragma warning(disable : 4996)
void f(int n) {
	if (n > 1) f(n / 2);
	printf("%d", n % 2);
}
int main(){	
	unsigned fpid, lpid, sid, root, pxor, ftid, tid,ltid, txor, i, shiny;
	unsigned seed, ec, pid;
	int hp, atk, def, spa, spd, spe, height, weight, scale, drops;
	char species[10], odd[10], tera[10], ability[10], nature[10], gender[10];
	printf("sid�� �Է��� �ּ���\n");
	scanf("%d", &sid);
	printf("tid�� �Է��� �ּ���\n");
	scanf("%d", &tid);
	root = sid * 1000000 + tid;
	printf("%d\n",root);
	printf("����� ��ȣ�� %x �Դϴ�\n",root);
	ftid = root / 65535;
	ltid = root % 65536;
	printf("����� ��Ű��ȣ ");
	txor = ftid ^ ltid;
	f(txor);
	printf("\n");

	FILE* fp;
	fp = fopen("asdf.csv","r");
	if (fp == NULL)
	{
		printf("������");
		return(1);
	}
	while (!feof(fp))
	{
		fscanf(fp, "%x,%s,%s,%x,%x,%s,%d,%d,%d,%d,%d,%d,%s,%s,%s,%d,%d,%d,%d\n",
			&seed, species, odd, &ec, &pid, tera, &hp, &atk, &def, &spa, &spd, &spe, ability, nature, gender, &height, &weight, &scale, &drops);
		fpid = pid / 65535;
		lpid = pid % 65536;
		pxor = fpid ^ lpid;
		shiny = pxor ^ txor;
		if (0 <= shiny && shiny <= 15) {
			printf("%x\n", pid);
			printf("%s %d %d %d %d %d %d %s %s %s %d %d %d %d\n", tera, hp, atk, def, spa, spd, spe, ability, nature, gender, height, weight, scale, drops);
		}
	}
}